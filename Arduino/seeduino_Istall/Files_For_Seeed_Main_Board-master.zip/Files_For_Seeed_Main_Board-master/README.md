Files_For_Seeed_Main_Board
==========================

Boards.txt and USBCore.cpp in Arduino IDE

# Arduino 1.6.3

See v1.6.3 for support files for Arduino 1.6.3
