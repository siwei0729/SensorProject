# Installation

Copy the `seeeduino` directory into either the `<sketchbook
directory>/hardware`, or directly into the Arduino installation
directory under `hardware/`
